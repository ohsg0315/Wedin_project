package com.hong.fragement.Event;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.hong.fragement.MovieObj;
import com.hong.fragement.R;

import java.util.ArrayList;
import java.util.List;

public class EventPage extends Fragment {

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    private RecyclerView recyclerView;
    private AdapterForEventPage mAdapterForEventPage;

    private List<EventInfo> listMovieObj;
    private EventInfo data;


    public EventPage() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.eventpage,container,false);

        listMovieObj = new ArrayList<EventInfo>();

        recyclerView = view.findViewById(R.id.recyclerview_eventpage);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));

        readImageUri();


        return view;




    }

    private void readOTTsiteLogoImage()
    {
        data = new EventInfo();

    }

    private void readImageUri()
    {
        data = new EventInfo();
        DocumentReference documentReference = db.collection("Event").document("wavve")
        documentReference.get().addOnCompleteListener(new OnSuccessListener<DocumentSnapshot>() {

            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {

            }

            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful())
                {
                    for (QueryDocumentSnapshot queryDocumentSnapshot : task.getResult())
                    {
                        data = queryDocumentSnapshot.toObject(EventInfo.class);
                        listMovieObj.add(data);
                        Log.d(this.getClass().getName(), "readImageUri실행");

                    }

                    mAdapterForEventPage = new AdapterForEventPage(listMovieObj, getActivity());
                    recyclerView.setAdapter(mAdapterForEventPage);
                }

            }
        });
    }
}
